import React from 'react'
import ReactDOM from 'react-dom/client'

function App() {
  return (
    <div className="p-10 text-center text-2xl font-bold text-lime-400">
      🚀 Nexora Online! (Fix definitivo con src/)
    </div>
  )
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />)
