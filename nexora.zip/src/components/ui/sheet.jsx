
import React from 'react'
export const Sheet = ({children}) => <div>{children}</div>
export const SheetTrigger = ({children}) => children
export const SheetContent = ({children}) => <div className="fixed top-0 right-0 w-80 h-full bg-zinc-900 border-l border-zinc-800 p-4">{children}</div>
